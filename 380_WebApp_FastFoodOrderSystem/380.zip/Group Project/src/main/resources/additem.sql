/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Scars
 * Created: 2021/5/2
 */


INSERT INTO item(itemname, description,price,quantity) VALUES ('shit','test',100,'Available');