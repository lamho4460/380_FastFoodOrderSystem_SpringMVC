package ouhk.comps380f.exception;

public class TicketNotFound extends Exception {
}

