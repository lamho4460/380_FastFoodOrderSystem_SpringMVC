package ouhk.comps380f.exception;

public class AttachmentNotFound extends Exception {
}

